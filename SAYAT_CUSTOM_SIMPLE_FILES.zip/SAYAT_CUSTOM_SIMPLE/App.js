import React, {useMemo, useState} from 'react';
import {SafeAreaView, ScrollView, View, Text, Pressable, StyleSheet, Alert} from 'react-native';

const widths=[1800,2000,2200,2500,2800,3000];
const options={
  chassis:[['standard','شاسی استاندارد'],['heavy','شاسی سنگین']],
  disc:[['d560x4','دیسک Ø560 × 4 mm'],['d560x6','دیسک Ø560 × 6 mm']],
  wheel:[['10/80-12','چرخ 10/80-12'],['340/55-16','چرخ 340/55-16']]
};

export default function App(){
 const [step,setStep]=useState(0);
 const [machine,setMachine]=useState('دیسک پشت تراکتور');
 const [width,setWidth]=useState(2500);
 const [chassis,setChassis]=useState('standard');
 const [disc,setDisc]=useState('d560x4');
 const [wheel,setWheel]=useState('10/80-12');
 const [hyd,setHyd]=useState(false), [led,setLed]=useState(false), [skf,setSkf]=useState(false);
 const valid=!(width>=3000&&chassis==='standard') && !(disc==='d560x6'&&chassis==='standard');
 const reasons=useMemo(()=>{const r=[]; if(width>=3000&&chassis==='standard')r.push('برای عرض 3000 میلی‌متر، شاسی سنگین لازم است.'); if(disc==='d560x6'&&chassis==='standard')r.push('دیسک 6 میلی‌متر با شاسی استاندارد در این نسخه مجاز نیست.'); return r},[width,chassis,disc]);
 const next=()=>{if(step<5)setStep(step+1); else {if(valid)Alert.alert('پروژه ثبت شد','پیکربندی SAYAT CUSTOM آماده بررسی فنی است.');}};
 const Choice=({title,data,value,onChange})=><View style={styles.block}><Text style={styles.label}>{title}</Text><View style={styles.row}>{data.map(([v,t])=><Pressable key={v} onPress={()=>onChange(v)} style={[styles.card,value===v&&styles.active]}><Text style={[styles.cardText,value===v&&styles.activeText]}>{t}</Text></Pressable>)}</View></View>;
 return <SafeAreaView style={styles.safe}><ScrollView contentContainerStyle={styles.container}>
   <Text style={styles.brand}>SAYAT CUSTOM</Text><Text style={styles.sub}>دستگاه اختصاصی شما</Text>
   <View style={styles.progress}><Text style={styles.progressText}>مرحله {step+1} از 6</Text></View>
   {step===0&&<><Text style={styles.title}>نوع دستگاه</Text><Pressable style={[styles.bigCard,styles.active]}><Text style={styles.bigText}>{machine}</Text></Pressable><Text style={styles.hint}>در نسخه بعدی انواع دستگاه‌های سایات اضافه می‌شوند.</Text></>}
   {step===1&&<><Text style={styles.title}>عرض کاری</Text><View style={styles.row}>{widths.map(w=><Pressable key={w} onPress={()=>setWidth(w)} style={[styles.card,width===w&&styles.active]}><Text style={[styles.cardText,width===w&&styles.activeText]}>{w} mm</Text></Pressable>)}</View></>}
   {step===2&&<><Text style={styles.title}>شاسی</Text><Choice title="انتخاب شاسی" data={options.chassis} value={chassis} onChange={setChassis}/></>}
   {step===3&&<><Text style={styles.title}>دیسک و چرخ</Text><Choice title="نوع دیسک" data={options.disc} value={disc} onChange={setDisc}/><Choice title="چرخ" data={options.wheel} value={wheel} onChange={setWheel}/></>}
   {step===4&&<><Text style={styles.title}>آپشن‌ها</Text>{[['hyd','تنظیم هیدرولیکی چرخ'],['led','چراغ و علائم هشدار'],['skf','توپی SKF']].map(([k,t])=>{const val={hyd,led,skf}[k];return <Pressable key={k} onPress={()=>({hyd:setHyd,led:setLed,skf:setSkf}[k])(!val)} style={[styles.option,val&&styles.active]}><Text style={[styles.cardText,val&&styles.activeText]}>{val?'✓  ':''}{t}</Text></Pressable>})}</>}
   {step===5&&<><Text style={styles.title}>خلاصه دستگاه</Text><View style={styles.summary}><Text style={styles.line}>دستگاه: {machine}</Text><Text style={styles.line}>عرض کاری: {width} mm</Text><Text style={styles.line}>شاسی: {chassis==='heavy'?'سنگین':'استاندارد'}</Text><Text style={styles.line}>دیسک: {disc==='d560x6'?'Ø560 × 6 mm':'Ø560 × 4 mm'}</Text><Text style={styles.line}>چرخ: {wheel}</Text><Text style={styles.line}>آپشن‌ها: {[hyd&&'هیدرولیک',led&&'LED',skf&&'SKF'].filter(Boolean).join('، ')||'بدون آپشن'}</Text></View><View style={[styles.status,valid?styles.ok:styles.bad]}><Text style={styles.statusText}>{valid?'✓ قابل تولید در محدوده فعلی':'⚠ نیازمند بررسی فنی'}</Text>{reasons.map((r,i)=><Text key={i} style={styles.reason}>{r}</Text>)}</View></>}
   <Pressable onPress={next} style={[styles.button,!valid&&step===5&&styles.disabled]}><Text style={styles.buttonText}>{step===5?'ثبت درخواست':'ادامه'}</Text></Pressable>
   {step>0&&<Pressable onPress={()=>setStep(step-1)}><Text style={styles.back}>مرحله قبل</Text></Pressable>}
 </ScrollView></SafeAreaView>
}
const styles=StyleSheet.create({safe:{flex:1,backgroundColor:'#f4f6f5'},container:{padding:22,paddingBottom:40},brand:{fontSize:30,fontWeight:'900',color:'#101714',textAlign:'center'},sub:{fontSize:16,color:'#64716b',textAlign:'center',marginTop:4},progress:{marginTop:18,backgroundColor:'#e1e7e3',padding:10,borderRadius:12},progressText:{textAlign:'center',fontWeight:'700',color:'#3d4944'},title:{fontSize:24,fontWeight:'900',marginTop:25,marginBottom:18,color:'#101714'},hint:{color:'#69756f',marginTop:14,lineHeight:22},row:{flexDirection:'row',flexWrap:'wrap',gap:10},card:{backgroundColor:'#fff',borderWidth:1,borderColor:'#d7dfda',borderRadius:14,padding:15,minWidth:'30%',flexGrow:1},active:{backgroundColor:'#111a16',borderColor:'#111a16'},cardText:{fontSize:15,fontWeight:'700',textAlign:'center',color:'#25302b'},activeText:{color:'#fff'},bigCard:{padding:24,borderRadius:18,borderWidth:1,alignItems:'center'},bigText:{fontSize:19,fontWeight:'800',color:'#fff'},block:{marginBottom:18},label:{fontWeight:'800',fontSize:17,marginBottom:10},option:{backgroundColor:'#fff',borderWidth:1,borderColor:'#d7dfda',borderRadius:14,padding:18,marginBottom:10},summary:{backgroundColor:'#fff',borderRadius:18,padding:18,gap:10},line:{fontSize:16,color:'#28332e'},status:{marginTop:14,borderRadius:16,padding:16},ok:{backgroundColor:'#dcefe3'},bad:{backgroundColor:'#fff0d7'},statusText:{fontSize:17,fontWeight:'900'},reason:{marginTop:6,color:'#5d4b2a'},button:{marginTop:22,backgroundColor:'#111a16',padding:18,borderRadius:16},disabled:{opacity:.45},buttonText:{color:'#fff',fontSize:18,fontWeight:'900',textAlign:'center'},back:{textAlign:'center',marginTop:16,color:'#56635d',fontWeight:'700'}});
